"""
CLI metadata source service
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'epytext en'

from .maps import get_shared_cli_maps

from com.vmware.vapi.common import message_factory
from com.vmware.vapi.metadata.cli_provider import (Command, Namespace, Source)
from com.vmware.vapi.metadata.util.sources_mixin import SourceMixin
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import ErrorFactory

logger = get_vapi_logger(__name__)

CLI = 'cli'


class SourceImpl(SourceMixin, Source):
    """
    Operations to manage the CLI metadata source
    """
    _generic_types_map = {
        '': Command.GenericType.NONE,
        'optional': Command.GenericType.OPTIONAL,
        'list': Command.GenericType.LIST,
        'optional_list': Command.GenericType.OPTIONAL_LIST,
        'list_optional': Command.GenericType.LIST_OPTIONAL
    }
    _formatter_types_map = {
        'simple': Command.FormatterType.SIMPLE,
        'table': Command.FormatterType.TABLE,
        'json': Command.FormatterType.JSON,
        'xml': Command.FormatterType.XML,
        'csv': Command.FormatterType.CSV,
        'html': Command.FormatterType.HTML,
    }

    def __init__(self, maps, cfg):
        """
        Initialize SourceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.CliMaps`
        :param maps: Dictionaries to store metadata
        """
        Source.__init__(self)
        SourceMixin.__init__(self, maps, CLI, cfg)

    @staticmethod
    def _get_namespace_identity(node):
        """
        Get the namespace identity object
        :rtype:
            :class:`com.vmware.vapi.metadata.cli_provider.Namespace.Identity`
        :return: Namespace identity
        """
        return Namespace.Identity(path=node.get('path'),
                                  name=node.get('name'))

    @staticmethod
    def _get_command_identity(node):
        """
        Get the command identity object
        :rtype: :class:`com.vmware.vapi.metadata.cli_provider.Command.Identity`
        :return: Command Identity
        """
        return Command.Identity(path=node.get('path'),
                                name=node.get('name'))

    @staticmethod
    def _get_parameter_list(node):
        """
        Get the command parameter info object
        :rtype:
            :class:`com.vmware.vapi.metadata.cli_provider.Command.OptionInfo`
        :return: Parameter info for a command
        """
        return Command.OptionInfo(long_option=node.get('long_option'),
                                  short_option=node.get('short_option'),
                                  field_name=node.get('field_name'),
                                  description=node.get('description'),
                                  type=node.get('type'),
                                  generic=SourceImpl._generic_types_map[
                                                        node.get('generic')])

    @staticmethod
    def _get_display_name_mapping(mapping):
        """
        Get the command display name map entry object
        :rtype:
            :class:`com.vmware.vapi.metadata.cli_provider.Command.OutputFieldInfo`  # pylint: disable=line-too-long
        :return: Display name mapping for output struct
        """
        return Command.OutputFieldInfo(field_name=mapping.get('field_name'),
                                       display_name=mapping.get('display_name'))

    def _get_field_map_list(self, node):
        """
        Get the command field map list object
        :rtype:
            :class:`com.vmware.vapi.metadata.cli_provider.Command.OutputInfo`
        :return: Field mapping for output struct
        """
        mapping_list = node.get('output_fields')
        return Command.OutputInfo(structure_id=node.get('structure_id'),
                                  output_fields=[
                                    self._get_display_name_mapping(mapping)
                                    for mapping in mapping_list])

    def _json_to_vapi_ns_struct(self, op_info, children_list):
        """
        Convert json object to NamespaceInfo object

        :type  op_info:
            :class:`com.vmware.vapi.metadata.cli_provider.Namespace.Info`
        :kwarg op_info: Json OperationInfo object
        :rtype: :class:`com.vmware.vapi.metadata.cli_provider.Namespace.Info`
        :return: Namespace info struct
        """
        key = self._get_namespace_identity(op_info)

        return Namespace.Info(identity=key,
                              description=op_info.get('description'),
                              children=children_list)

    def _json_to_vapi_cmd_struct(self, op_info):
        """
        Convert json object to CommandInfo object

        :type  op_info:
            :class:`com.vmware.vapi.metadata.cli_provider.Command.Info`
        :kwarg op_info: Json OperationInfo object
        :rtype: :class:`com.vmware.vapi.metadata.cli_provider.Command.Info`
        :return: Command info struct
        """

        key = self._get_command_identity(op_info)

        node_metadata = op_info.get('node_metadata')
        option_list = node_metadata.get('options', [])
        output_list = node_metadata.get('output_field_list', [])
        field_map_list = [self._get_field_map_list(output)
                          for output in output_list]
        formatter = node_metadata.get('formatter')
        if formatter:
            formatter = SourceImpl._formatter_types_map[formatter]

        return Command.Info(identity=key,
                            description=op_info.get('description'),
                            service_id=node_metadata.get('service_id'),
                            operation_id=node_metadata.get('operation_id'),
                            options=[self._get_parameter_list(option)
                                     for option in option_list],
                            formatter=formatter,
                            output_field_list=field_map_list)

    def build_namespace_tree(self, key, ns_tree):
        """
        Method to convert CLI namespace into a tree

        :type   key: :class:`str`
        :param  key: CLI namespace
        :type   ns_tree: :class:`dict`
        :param  ns_tree: Nested input dictionary
        """
        parts = key.rsplit('.', 1)
        if len(parts) > 1:
            ns_tree.setdefault(parts[0], set([])).add(parts[1])
            self.build_namespace_tree(parts[0], ns_tree)

    def _parse_json_metadata(self, source_id, json_metadata_list):
        """
        Parse json metadata

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  json_metadata_list: :class:`list` of :class:`dict`
        :param json_metadata_list: Cli metadata list
        """

        if not json_metadata_list:
            return

        namespace_tree = {}
        ns_keys = []

        # Build a tree of namespace nodes to use later for getting node children
        for metadata in json_metadata_list:
            if metadata.get('type') == 'namespace':
                key = '%s.%s' % (metadata.get('path'), metadata.get('name'))
                ns_keys.append(key)
                namespace_tree.setdefault(key, set([]))
                self.build_namespace_tree(key, namespace_tree)

        # Parse the metadata
        for metadata in json_metadata_list:
            path = metadata.get('path')
            name = metadata.get('name')
            type_ = metadata.get('type')
            namespace = '%s.%s' % (path, name) if name else path
            key = '%s#%s#%s' % (path, name, type_)

            if type_ == 'namespace':
                # Store (source_id, Namespace Info) tuple for each key
                children_list = set(  # pylint: disable=consider-using-set-comprehension
                    [Namespace.Identity(path=namespace, name=val)
                        for val in namespace_tree[namespace]])
                self._maps.namespace_info.setdefault(key, []).append((
                                            source_id,
                                            self._json_to_vapi_ns_struct(
                                                metadata,
                                                list(children_list))))
            elif type_ == 'command':
                # Store (source_id, Command Info) tuple for each key
                self._maps.command_info.setdefault(key, []).append((
                    source_id, self._json_to_vapi_cmd_struct(metadata)))
            else:
                msg = message_factory.get_message(
                    'com.vmware.vapi.metadata.cli.sources.invalid_argument',
                    type_)
                logger.error(msg)
                raise ErrorFactory.new_invalid_argument(messages=[msg])

        root_ns_keys = []

        # Store (source_id, Namespace Info) tuples for each undeclared
        # namespace keys
        for k in list(set(namespace_tree.keys()) - set(ns_keys)):
            children = set([Namespace.Identity(path=k, name=val)  # pylint: disable=consider-using-set-comprehension
                            for val in namespace_tree[k]])
            key_split = k.rsplit('.', 1)

            if len(key_split) > 1:
                path = key_split[0]
            else:
                path = ''
                root_ns_keys.append(key_split[-1])

            key = '%s#%s#%s' % (path, key_split[-1], 'namespace')
            identity = Namespace.Identity(path=path, name=key_split[-1])

            key_ns_info = Namespace.Info(identity=identity,
                                         description='%s namespace'
                                         % key_split[-1],
                                         children=list(children))
            self._maps.namespace_info.setdefault(key, []).append((
                source_id, key_ns_info))

        # Store (source_id, Info) tuples for root namespace key
        root_identity = Namespace.Identity(path='', name='')
        root_key = '%s#%s#%s' % ('', '', 'namespace')
        root_children = set([Namespace.Identity(path='', name=val)  # pylint: disable=consider-using-set-comprehension
                            for val in root_ns_keys])
        root_ns_info = Namespace.Info(identity=root_identity,
                                      description='Root namespace',
                                      children=list(root_children))
        self._maps.namespace_info.setdefault(root_key, []).append((
            source_id, root_ns_info))

    def _parse_remote_metadata(self, source_id, stub_factory):
        """
        Parse metadata obtained from a remote source

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  stub_factory: :class:`vmware.vapi.bindings.stub.StubFactory`
        :param stub_factory: Stub factory
        """
        if not stub_factory:
            return

        namespace_stub = stub_factory.create_stub(
                            'com.vmware.vapi.metadata.cli.namespace')

        for ns_id in namespace_stub.list():
            ns_info = namespace_stub.get(identity=ns_id)
            key = '%s#%s#%s' % (ns_info.identity.path,
                                ns_info.identity.name, 'namespace')
            self._maps.namespace_info.setdefault(key, []).append((
                                        source_id, ns_info))

        command_stub = stub_factory.create_stub(
                            'com.vmware.vapi.metadata.cli.command')

        for cmd_id in command_stub.list():
            cmd_info = command_stub.get(identity=cmd_id)
            key = '%s#%s#%s' % (cmd_info.identity.path,
                                cmd_info.identity.name, 'command')
            self._maps.command_info.setdefault(key, []).append((
                        source_id, cmd_info))


def register_instance(source_conf):
    """
    Specify the instances that should be
    registered with the api provider
    """
    src_obj = SourceImpl(get_shared_cli_maps(), source_conf)
    return [src_obj]
