"""
Implementation of privilege metadata service
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long
__docformat__ = 'restructuredtext en'

import six

from com.vmware.vapi.common import message_factory
from com.vmware.vapi.metadata.privilege_provider import (
    Package, Component, Service, Source, ComponentData,
    PackageInfo, OperationInfo, PrivilegeInfo, ComponentInfo,
    ServiceInfo)
from com.vmware.vapi.metadata.privilege.service_provider import Operation
from com.vmware.vapi.metadata.util.maps import get_privilege_maps
from com.vmware.vapi.metadata.util.sources_mixin import SourceMixin
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import ErrorFactory

logger = get_vapi_logger(__name__)
PRIVILEGE = 'privilege'
default = 'default'


class OperationImpl(Operation):
    """
    Operations to retrieve information about privileges in a vAPI operation.
    An operation is said to contain privilege information if there are any
    privileges assigned to the operation directly or if one of its parameters
    has privileges assigned in privilege definition file.
    """
    def __init__(self, maps):
        """
        Initialize OperationImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Operation.__init__(self)
        self._maps = maps

    def list(self, service_id):
        """
        Get the IDs of all the vAPI operations in the given service that
        contain privilege information.

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service.
        :rtype: :class:`list` of :class:`str`
        :return: list of operation identifiers.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the service identifier does not exist.
        """
        if service_id not in self._maps.service_info:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.privilege.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return [op_name
                for service_name, op_name in self._maps.operation_info.keys()
                if service_id == service_name]

    def get(self, service_id, operation_id):
        """
        Get information about a vAPI operation that contains privilege
        information.

        :type  service_id: :class:`str`
        :param service_id: Identifier of the service.
        :type  operation_id: :class:`str`
        :param operation_id: Identifier of the operation.
        :rtype:
            :class:`com.vmware.vapi.metadata.privilege_provider.OperationInfo`
        :return: Operation info for the vAPI operation that
            contains privilege information.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the service identifier does not exist.
        """
        operation_info = self._maps.operation_info.get((service_id,
                                                        operation_id))
        if operation_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.privilege.operation.not_found',
                operation_id, service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return operation_info


class PackageImpl(Package):
    """
    Operations to retrieve information about privileges in a vAPI package.
    A Package contains privilege information if there is a default
    privilege assigned to all operations within a package or if one of the
    operations within this package has privilege information.
    """
    def __init__(self, maps):
        """
        Initialize PackageImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Package.__init__(self)
        self._maps = maps

    def list(self):
        """
        List of all vAPI packages that have privilege information.

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified package identifiers.
        """
        return self._maps.package_info.keys()

    def get(self, package_id):
        """
        Get the privilege information for a vAPI package.

        :type  package_id: :class:`str`
        :param package_id: fully qualified package identifier.
        :rtype: :class:`com.vmware.vapi.metadata.privilege_provider.PackageInfo`
        :return: privilege information for the vAPI package.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the package identifier does not exist.
        """
        package_info = self._maps.package_info.get(package_id)
        if package_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.privilege.package.not_found',
                package_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return package_info


class ComponentImpl(Component):
    """
    Operations to retrieve information about the privileges in a vAPI
    component. A Component contains privilege information if any of its
    packages contain privilege information.
    """
    def __init__(self, maps):
        """
        Initialize ComponentImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Component.__init__(self)
        self._maps = maps

    def list(self):
        """
        List all the vAPI components that contain operations which have
        privilege information.

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified component identifiers.
        """
        return self._maps.component_info.keys()

    def get(self, component_id):
        """
        Get the privilege information for a vAPI component.

        :type  component_id: :class:`str`
        :param component_id: fully qualified component identifier.
        :rtype:
            :class:`com.vmware.vapi.metadata.privilege_provider.ComponentData`
        :return: privilege information for the vAPI component.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the component identifier does not exist.
        """
        component_info = self._maps.component_info.get(component_id)
        if component_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.privilege.component.not_found',
                component_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return ComponentData(info=component_info,
                             fingerprint=self.fingerprint(
                                            component_id=component_id))

    def fingerprint(self, component_id):
        """
        Fingerprint of all privilege metadata for a vAPI component on the
        server.

        :type  component_id: :class:`str`
        :param component_id: fully qualified component identifier.
        :rtype: :class:`str`
        :return: fingerprint of privilege metadata for a vAPI component.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the component identifier does not exist.
        """
        fingerprint = self._maps.component_fingerprints.get(component_id)
        if fingerprint is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.privilege.component.not_found',
                component_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return fingerprint


class ServiceImpl(Service):
    """
    Operations to retrieve information about privilege information of a
    vAPI service.
    """
    def __init__(self, maps):
        """
        Initialize ServiceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        """
        Service.__init__(self)
        self._maps = maps

    def list(self):
        """
        Get list of all vAPI services that have operations with privilege
        information.

        :rtype: :class:`list` of :class:`str`
        :return: list of fully qualified service identifiers.
        """
        return self._maps.service_info.keys()

    def get(self, service_id):
        """
        Get the privilege information for a vAPI service.

        :type  service_id: :class:`str`
        :param service_id: fully qualified service identifier.
        :rtype: :class:`com.vmware.vapi.metadata.privilege_provider.ServiceInfo`
        :return: identifier information for the vAPI service.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            If the service identifier does not exist.
        """
        service_info = self._maps.service_info.get(service_id)
        if service_info is None:
            msg = message_factory.get_message(
                'com.vmware.vapi.metadata.privilege.service.not_found',
                service_id)
            logger.info(msg)
            raise ErrorFactory.new_not_found(messages=[msg])
        return service_info


class SourceImpl(SourceMixin, Source):
    """
    Operations to manage the metadata sources for privilege information
    """
    def __init__(self, maps, cfg):
        """
        Initialize SourceImpl

        :type  maps: :class:`com.vmware.vapi.metadata.util.maps.MetadataMaps`
        :param maps: Dictionaries to store metadata
        :type  cfg: :class:`dict` of :class:`str` and :class:`str`
        :param cfg: Configuration for the service specified in the properties
            file
        """
        Source.__init__(self)
        SourceMixin.__init__(self, maps, PRIVILEGE, cfg)

    @staticmethod
    def _parse_json_operation_metadata(operation_metadata):
        """
        Parse operation metadata from json object

        :type  operation_metadata: :class:`dict`
        :param operation_metadata: Operation metadata
        :rtype: :class:`dict`
        :return: Operation metadata after processing
        """
        operation_data = {}
        for path, privileges in six.iteritems(operation_metadata):
            privileges = [privilege for privilege in privileges]
            tokens = path.split('.')
            operation_name = tokens[0]
            operation_info = operation_data.get(
                operation_name,
                OperationInfo(privileges=[], privilege_info=[]))
            # If there is only one token, the privileges are assigned
            # to the operation, otherwise they are assigned to the opeartion
            # parameters
            if len(tokens) > 1:
                property_path = '.'.join(tokens[1:])
                privilege_info = PrivilegeInfo(property_path=property_path,
                                               privileges=privileges)
                operation_info.privilege_info.append(privilege_info)
            else:
                operation_info.privileges = privileges
            operation_data[operation_name] = operation_info
        return operation_data

    @staticmethod
    def _parse_json_package_metadata(package_metadata):
        """
        Parse package metadata from json object

        :type  package_metadata: :class:`dict`
        :param package_metadata: Operation metadata
        :rtype: :class:`dict`
        :return: Package metadata after processing
        """
        package_map = {}
        if package_metadata:
            for package_name, privileges in six.iteritems(package_metadata):
                privileges = [privilege for privilege in privileges]
                package_info = PackageInfo(privileges=privileges, services={})
                package_map[package_name] = package_info
        return package_map

    def _parse_json_component_info(self, id_, component_metadata):
        """
        Parse privilege metadata from a config file

        :type  id_: :class:`str`
        :param id_: Source identifier
        :type  component_name: :class:`str`
        :param component_name: Component name
        :type  component_metadata: :class:`ConfigParser`
        :param component_metadata: ConfigParser object of the privilege
            definition file
        """
        metadata_keys = list(component_metadata.keys())

        # remove key that has component name
        metadata_keys.remove('name')

        if not metadata_keys:
            # There is no privilege metadata present for
            # this component in the json file
            return None

        package_map = self._parse_json_package_metadata(
            component_metadata.get(default))

        # package default is already handled
        metadata_keys.remove(default)

        # The remaining metadata keys are all service names
        # Process service specific privileges
        for service_name in metadata_keys:
            tokens = service_name.split('.')
            package_name = '.'.join(tokens[:-1])
            package_info = package_map.get(package_name,
                                           PackageInfo(privileges=[],
                                                       services={}))

            # Process privileges for operations
            service_metadata = component_metadata.get(service_name)
            operation_data = self._parse_json_operation_metadata(
                service_metadata)

            service_info = ServiceInfo(operations={})
            for k, v in six.iteritems(operation_data):
                self._maps.operation_info[(service_name, k)] = v
                self._maps.operation_mapping.setdefault(
                                                id_,
                                                []).append((service_name, k))
                service_info.operations[k] = v

            self._maps.service_info[service_name] = service_info
            self._maps.service_mapping.setdefault(id_, []).append(service_name)
            package_info.services[service_name] = service_info
            package_map[package_name] = package_info

        # Create ComponentInfo object
        component_info = ComponentInfo(packages={})
        for k, v in six.iteritems(package_map):
            self._maps.package_info[k] = v
            self._maps.package_mapping.setdefault(id_, []).append(k)
            component_info.packages[k] = v
        return component_info

    def _parse_json_metadata(self, source_id, idl_metadata):
        """
        Parse metadata obtained from a file

        :type  source_id: :class:`str`
        :param source_id: Source metamodel
        :type  idl_metadata: :class:`list` of :class:`dict`
        :param idl_metadata: metamodel metadata
        """
        if not idl_metadata:
            return

        component_data = idl_metadata.get('component')
        if not component_data:
            # Backward compatibility
            component_data = idl_metadata.get('product')
        component_name = component_data.get('name')

        component_info = self._parse_json_component_info(source_id,
                                                         component_data)
        self._maps.component_info[component_name] = component_info

        self._maps.component_mapping.setdefault(source_id,
                                                []).append(component_name)

        fingerprint = self._generate_fingerprint(component_info)
        self._maps.component_fingerprints[component_name] = fingerprint

    def _parse_remote_service_info(self, source_id, service_name, service_info):
        """
        Parse ServiceInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  service_name: :class:`str`
        :param service_name: Service Name
        :type  service_info:
            :class:`com.vmware.vapi.metadata.privilege_provider.ServiceInfo`
        :param service_info: ServiceInfo object
        """
        for name, info in six.iteritems(service_info.operations):
            self._maps.operation_info[(service_name, name)] = info
            self._maps.operation_mapping.setdefault(source_id, []).append(
                (service_name, name))

    def _parse_remote_package_info(self, source_id, package_info):
        """
        Parse PackageInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  package_info:
            :class:`com.vmware.vapi.metadata.privilege_provider.PackageInfo`
        :param package_info: PackageInfo object
        """
        for name, info in six.iteritems(package_info.services):
            self._parse_remote_service_info(source_id, name, info)
            self._maps.service_info[name] = info
            self._maps.service_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_component_info(self, source_id, component_info):
        """
        Parse ComponentInfo remote data

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  component_info:
            :class:`com.vmware.vapi.metadata.privilege_provider.ComponentInfo`
        :param component_info: ComponentInfo object
        """
        for name, info in six.iteritems(component_info.packages):
            self._parse_remote_package_info(source_id, info)
            self._maps.package_info[name] = info
            self._maps.package_mapping.setdefault(source_id, []).append(name)

    def _parse_remote_metadata(self, source_id, stub_factory):
        """
        Parse metadata obtained from a remote source

        :type  source_id: :class:`str`
        :param source_id: Source identifier
        :type  stub_factory: :class:`vmware.vapi.bindings.stub.StubFactory`
        :param stub_factory: Stub factory
        """
        if not stub_factory:
            return
        component_stub = stub_factory.create_stub(
            'com.vmware.vapi.metadata.privilege.component')
        for component_id in component_stub.list():
            component_data = component_stub.get(component_id=component_id)
            self._parse_remote_component_info(source_id, component_data.info)
            self._maps.component_info[component_id] = component_data.info

            self._maps.component_mapping.setdefault(source_id,
                                                    []).append(component_id)
            self._maps.component_fingerprints[component_id] = \
                component_data.fingerprint


def register_instance(cfg):
    """
    Specify the instances that should be
    registered with the api provider

    :type  cfg: :class:`dict` of :class:`str` and :class:`str`
    :param cfg: Configuration for the service specified in the properties file
    """
    maps = get_privilege_maps()
    return [
        OperationImpl(maps),
        PackageImpl(maps),
        ComponentImpl(maps),
        ServiceImpl(maps),
        SourceImpl(maps, cfg),
    ]
