"""
Type converter from vAPI bindings data model to Metamodel data model
"""
__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2015-2017 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

from com.vmware.vapi.metadata.metamodel_provider import (
    Type, UserDefinedType, GenericInstantiation, StructureInfo, FieldInfo,
    ElementValue, ElementMap, EnumerationInfo)
from vmware.vapi.bindings.type import (
    BindingTypeVisitor, StructType, EnumType)
from vmware.vapi.lib.log import get_vapi_logger

logger = get_vapi_logger(__name__)


class MetamodelBindingVisitor(BindingTypeVisitor):
    """
    Visitor to extract Metamodel type information from Static bindings
    """
    def __init__(self, resolved_structures=None):
        BindingTypeVisitor.__init__(self)
        self._out_value = None
        self._metadata = {}
        self._resolved_structures = resolved_structures

    def get_out_value(self):
        """
        Returns the dictionary that has the structure names and
        structure metamodel information.

        :rtype: :class:`dict` of :class:`str` to
            :class:`com.vmware.vapi.metadata.metamodel_provider.StructureInfo`
        :return: Dictionary of structure names to the metamodel information of
            the structure
        """
        return self._resolved_structures

    def visit_void(self, typ):  # pylint: disable=W0613
        """
        Visit a void value (i.e. None)

        :type  typ: :class:`VoidType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.VOID)

    def visit_integer(self, typ):  # pylint: disable=W0613
        """
        Visit an integer value

        :type  typ: :class:`IntegerType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.LONG)

    def visit_double(self, typ):  # pylint: disable=W0613
        """
        Visit a double value

        :type  typ: :class:`DoubleType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.DOUBLE)

    def visit_string(self, typ):  # pylint: disable=W0613
        """
        Visit a string value

        :type  typ: :class:`StringType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.STRING)

    def visit_boolean(self, typ):  # pylint: disable=W0613
        """
        Visit a boolean value

        :type  typ: :class:`BooleanType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.BOOLEAN)

    def visit_blob(self, typ):  # pylint: disable=W0613
        """
        Visit a blob value

        :type  typ: :class:`BlobType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.BINARY)

    def visit_dynamic_struct(self, typ):  # pylint: disable=W0613
        """
        Visit a struct value

        :type  typ: :class:`StructType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.DYNAMIC_STRUCTURE)

    def visit_opaque(self, typ):  # pylint: disable=W0613
        """
        Visit an opaque value.

        :type  typ: :class:`OpaqueType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.OPAQUE)

    def visit_secret(self, typ):  # pylint: disable=W0613
        """
        Visit a secret value

        :type  typ: :class:`SecretType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.SECRET)

    def visit_date_time(self, typ):  # pylint: disable=W0613
        """
        Visit a datetime value

        :type  typ: :class:`DateTimeType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.DATE_TIME)

    def visit_uri(self, typ):  # pylint: disable=W0613
        """
        Visit an URI value

        :type  typ: :class:`URIType`
        :param typ: Binding type of the value
        """
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.URI)

    def visit_id(self, typ):
        """
        Visit a ID value

        :type  typ: :class:`IdType`
        :param typ: Binding type of the value
        """
        elements = {}
        resource_types = typ.resource_types
        if resource_types is not None:
            if len(resource_types) == 1:
                element_value = ElementValue(type=ElementValue.Type.STRING,
                                             string_value=resource_types[0])
                elements['value'] = element_value
            elif len(resource_types) > 1:
                element_value = ElementValue(type=ElementValue.Type.STRING_LIST,
                                             list_value=resource_types)
                elements['value'] = element_value
        resource_type_field_name = typ.resource_type_field_name
        if resource_type_field_name:
            element_value = ElementValue(type=ElementValue.Type.STRING,
                                         string_value=resource_type_field_name)
            elements['typeHolder'] = element_value
        self._metadata = {}
        if elements:
            self._metadata['Resource'] = ElementMap(elements=elements)
        self._out_value = Type(category=Type.Category.BUILTIN,
                               builtin_type=Type.BuiltinType.ID)

    def _visit_generic(self, element_type, generic_type):
        """
        Visit a generic type

        :type  element_type: :class:`vmware.vapi.bindings.type.BindingType`
        :param element_type: Binding type
        :type  generic_type:
            :class:`com.vmware.vapi.metadata.metamodel_provider.GenericInstantiation.GenericType`
        :param generic_type: Generic type
        """
        element_type.accept(self)
        generic = GenericInstantiation(
            generic_type=generic_type,
            element_type=self._out_value)
        out_value = Type(category=Type.Category.GENERIC,
                         generic_instantiation=generic)
        self._out_value = out_value

    def visit_optional(self, typ):
        """
        Visit an optional value

        :type  typ: :class:`OptionalType`
        :param typ: Binding type of the value
        """
        self._visit_generic(typ.element_type,
                            GenericInstantiation.GenericType.OPTIONAL)

    def visit_list(self, typ):
        """
        Visit a list value

        :type  typ: :class:`ListType`
        :param typ: Binding type of the value
        """
        self._visit_generic(typ.element_type,
                            GenericInstantiation.GenericType.LIST)

    def visit_set(self, typ):
        """
        Visit a set value

        :type  typ: :class:`SetType`
        :param typ: Binding type of the value
        """
        self._visit_generic(typ.element_type,
                            GenericInstantiation.GenericType.SET)

    def visit_map(self, typ):
        """
        Visit a map value

        :type  typ: :class:`MapType`
        :param typ: Binding type of the value
        """
        typ.key_type.accept(self)
        key_type = self._out_value
        typ.value_type.accept(self)
        value_type = self._out_value
        generic = GenericInstantiation(
            generic_type=GenericInstantiation.GenericType.MAP,
            map_key_type=key_type,
            map_value_type=value_type)
        out_value = Type(category=Type.Category.GENERIC,
                         generic_instantiation=generic)
        self._out_value = out_value

    def visit_struct(self, typ):
        """
        Visit a struct value

        :type  typ: :class:`StructType`
        :param typ: Binding type of the value
        """
        fields = {}
        for field_name in typ.get_field_names():
            field_type = typ.get_field(field_name)
            field_type.accept(self)
            field_type = self._out_value
            fields[field_name] = FieldInfo(name=field_name,
                                           type=field_type,
                                           metadata=self._metadata,
                                           documentation='')
            self._metadata = {}
        metadata = {}
        if typ.is_model:
            elements = {'value': ElementValue(type=ElementValue.Type.STRING,
                                              string_value='true')}
            metadata['Model'] = ElementMap(elements=elements)
            for model_key in typ.model_keys:
                field_info = fields[model_key]
                if field_info:
                    field_info.metadata['ModelKey'] = ElementMap(
                            elements=elements)
        # TODO: Populate enumerations for this structure
        struct_info = StructureInfo(enumerations={},
                                    fields=list(fields.values()),
                                    metadata=metadata,
                                    documentation='')
        self._resolved_structures[typ.name] = struct_info

    def visit_error(self, typ):
        """
        Visit an error type

        :type  typ: :class:`ErrorType`
        :param typ: Binding type of the value
        """
        self.visit_struct(typ)

    def visit_enum(self, typ):
        """
        Visit a enum value

        :type  typ: :class:`EnumType`
        :param typ: Binding type of the value
        """
        # TODO: extract the values from EnumType
        # IS serializer doesn't use EnumerationInfo now
        self._out_value = EnumerationInfo(name=typ.name,
                                          values=[],
                                          documentation='',
                                          metadata={})

    def visit_reference(self, typ):
        """
        Visit a reference type

        :type  typ: :class:`ReferenceType`
        :param typ: Binding type of the value
        """
        typ = typ.resolved_type
        typ.accept(self)
        if isinstance(typ, StructType):
            self._out_value = Type(
                category=Type.Category.USER_DEFINED,
                user_defined_type=UserDefinedType(
                    resource_type='com.vmware.vapi.structure',
                    resource_id=typ.name))
        elif isinstance(typ, EnumType):
            self._out_value = Type(
                category=Type.Category.USER_DEFINED,
                user_defined_type=UserDefinedType(
                    resource_type='com.vmware.vapi.enumeration',
                    resource_id=typ.name))

    def visit_any_error(self, typ):
        """
        Visit any error type

        :type  typ: :class:`AnyErrorType`
        :param typ: Binding type of the value
        """
        raise NotImplementedError


class BindingToMetamodel(object):
    """
    Converter class that converts values from vAPI data model to Python native
    data model
    """

    @staticmethod
    def convert(binding_class):
        """
        Converts vAPI DataValue to Python native value

        :type  binding_class: :class:`vmware.vapi.bindings.struct.VapiStruct`
        :param binding_class: VapiStruct
        :rtype: :class:`dict` of :class:`str` to :class:`com.vmware.vapi.metadata.metamodel.StructureInfo`
        :return: Python native value
        """
        visitor = MetamodelBindingVisitor({})
        binding_class.get_binding_type().accept(visitor)
        return visitor.get_out_value()
