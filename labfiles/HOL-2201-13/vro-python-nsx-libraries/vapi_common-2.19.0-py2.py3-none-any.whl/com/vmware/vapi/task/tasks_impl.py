"""
Tasks Service Implementation
"""

__author__ = 'VMware, Inc.'
__copyright__ = 'Copyright 2017-2018 VMware, Inc.  All rights reserved. -- VMware Confidential'  # pylint: disable=line-too-long

from com.vmware.vapi.common import message_factory
from com.vmware.cis_provider import Tasks
from com.vmware.cis.task_provider import Info
from vmware.vapi.security.privilege import get_privilege_validator
from vmware.vapi.bindings.converter import TypeConverter
from vmware.vapi.task.task_manager_impl import get_task_manager
from vmware.vapi.lib.constants import AUTHN_IDENTITY
from vmware.vapi.lib.log import get_vapi_logger
from vmware.vapi.stdlib.provider.factories import ErrorFactory

logger = get_vapi_logger(__name__)


def has_privileges(sec_ctx, info):
    """
    Check if the given user has the privileges to access the task

    :type   sec_ctx: :class:`vmware.vapi.core.SecurityContext`
    :param: sec_ctx: Security Context
    :type:  info: :class:`com.vmware.cis.task_provider.Info`
    :param: info: Information about the specified task.

    :rtype: :class:`bool`
    :return: True if user has privileges
    """
    if sec_ctx is None:
        return True

    user_identity = sec_ctx.get(AUTHN_IDENTITY)
    if user_identity is None:
        return True

    user = user_identity.get_username()
    # User who created the task always has the permission
    if user == info.user:
        return True

    target = info.target

    if target is not None:
        # Check the user has permission on the target entity
        task_privilege_validator = get_privilege_validator()
        return task_privilege_validator.validate(user_identity,
                                                 target.id)

    return True


class TasksAuthzHandler(object):
    """
    Authorization Handler to check if the user has permissions to task's
    target resource
    """
    def authorize(self, service_id, operation_id, input_value, sec_ctx):
        """
        Verifies the provided authentication data against the permissions
        required for the task target resource.
        """

        if service_id != 'com.vmware.cis.tasks':
            return False

        # For Tasks.list operation authorization is done as part of the
        # method implementation as 'list' doesn't have a target resource
        # associated with it.
        if operation_id == 'list':
            return True

        if operation_id in ['get', 'cancel']:
            # Get the task id from the input value
            task_id = input_value.get_field('task').value
            task_manager = get_task_manager()
            info_value = task_manager.get_info(task_id)
            info = TypeConverter.convert_to_python(info_value,
                                                   Info.get_binding_type())

        return has_privileges(sec_ctx, info)


class TasksImpl(Tasks):
    """
    A basic ``Tasks`` class provides methods for managing the task related to a
    long running operation.
    """
    def __init__(self):
        Tasks.__init__(self)

    def get(self,
            task,
            spec=None,
            ):
        """
        Returns information about a task.

        :type  task: :class:`str`
        :param task: Task identifier.
            The parameter must be an identifier for the resource type:
            `com.vmware.cis_provider.Tasks`.
        :type  spec: :class:`Tasks.GetSpec` or `None`
        :param spec: Specification on what to get for a task.
            If None, use default values in the GetSpec.
        :rtype: :class:`com.vmware.cis.task_provider.Info`
        :return: Information about the specified task.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Error`
            if the system reports an error while responding to the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            if the task is not found.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.ResourceInaccessible` if the
             task's state cannot be accessed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.ServiceUnavailable`
            if the system is unable to communicate with a service to complete
            the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthenticated`
            if the user can not be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthorized`
            if the user doesn't have the required privileges.
        """
        task_manager = get_task_manager()
        try:
            info_value = task_manager.get_info(task)
            info = TypeConverter.convert_to_python(info_value,
                                                   Info.get_binding_type())
            if spec is not None:
                if spec.exclude_result:
                    info.result = None
        except KeyError:
            msg = message_factory.get_message('com.vmware.vapi.task.not_found',
                                              task)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])

        return info

    def list(self,
             filter_spec=None,
             result_spec=None
             ):
        """
        Returns information for a list of tasks.

        :type  filter_spec: :class:`com.vmware.cis_provider.Tasks.FilterSpec`
        :param filter_spec: Filter the results when listing tasks.
            Currently required. In the future, if None, use default values in
            the GetSpec.
        :type  result_spec: :class:`Tasks.GetSpec` or ``None``
        :param result_spec: Specification on what to get for a task.
            If None, use default values in the GetSpec.
        :rtype: :class:`dict` of :class:`str` and
                :class:`com.vmware.cis.task_provider.Info`
        :return: Map of task identifier to information about the task.
            The key in the return value :class:`dict` will be an identifier for
            the resource type: `com.vmware.cis_provider.Tasks`.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Error`
            if the system reports an error while responding to the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            if the task is not found.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.ResourceInaccessible` if the
             task's state cannot be accessed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.ServiceUnavailable`
            if the system is unable to communicate with a service to complete
            the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthenticated`
            if the user can not be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthorized`
            if the user doesn't have the required privileges.
        """
        if filter_spec is None:
            msg = message_factory.get_message(
                    'com.vmware.vapi.task.no_filter_spec')
            logger.error(msg)
            raise ErrorFactory.new_invalid_argument(messages=[msg])
        if not filter_spec.tasks and not filter_spec.services:
            msg = message_factory.get_message(
                      'com.vmware.vapi.task.no_tasks_or_services_in_filter')
            logger.error(msg)
            raise ErrorFactory.new_invalid_argument(messages=[msg])

        task_manager = get_task_manager()

        info_map = {}
        infos = task_manager.get_infos()
        for task_id, info_value in infos.items():
            info = TypeConverter.convert_to_python(info_value,
                                                   Info.get_binding_type())
            if self.is_filtered(filter_spec, task_id, info)\
                    and self.is_authorized(info):
                if result_spec is not None and \
                   result_spec.exclude_result:
                    info.result = None

                info_map.setdefault(task_id, info)

        return info_map

    def is_authorized(self, info):
        """
        Checks if the user is authorized to access the task

        :type info: :class:`com.vmware.cis.task_provider.Info`
        :param info: Information about the specified task.

        :rtype: :class:`bool`
        :return: True if user is authorized
        """
        execution_context = self.execution_context
        if execution_context is not None:
            return has_privileges(execution_context.security_context, info)

        return True

    def is_filtered(self, filter_spec, task, info):
        """
        Returns True if the given task is filtered.

        :type  filter_spec: :class:`com.vmware.cis_provider.Tasks.FilterSpec`
        :param filter_spec: Filter the results when listing tasks.
            Currently required. In the future, if None, use default values in
            the GetSpec.
        :type  task: :class:`str`
        :param task: Task identifier.
            The parameter must be an identifier for the resource type:
            ``com.vmware.cis_provider.Tasks``.
        :type info: :class:`com.vmware.cis.task_provider.Info`
        :param info: Information about the specified task.
        """
        if filter_spec.tasks is not None and \
                len(filter_spec.tasks) > 0 and \
                task not in filter_spec.tasks:
            return False
        if filter_spec.services is not None and \
                len(filter_spec.services) > 0 and \
                info.service not in filter_spec.services:
            return False
        if filter_spec.status is not None and \
                len(filter_spec.status) > 0 and \
                info.status not in filter_spec.status:
            return False
        if filter_spec.targets is not None and \
                len(filter_spec.targets) > 0 and \
                info.target not in filter_spec.targets:
            return False
        if filter_spec.users is not None and \
                len(filter_spec.users) > 0 and \
                info.user not in filter_spec.users:
            return False
        if filter_spec.operations is not None and \
                len(filter_spec.operations) > 0 and \
                info.operation not in filter_spec.operations:
            return False

        return True

    def cancel(self,
               task,
               ):
        """
        Cancel a running task. This is the best effort. Task cannot be
        cancelled anymore once it reaches certain stage.

        :type  task: :class:`str`
        :param task: Task identifier.
            The parameter must be an identifier for the resource type:
            ``com.vmware.cis_provider.Tasks``.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Error`
            if the system reports an error while responding to the request.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.NotAllowedInCurrentState` if
             the task is already canceled or completed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.NotFound`
            if the task is not found.
        :raise: :class:
            `com.vmware.vapi.std.errors_provider.ResourceInaccessible` if the
             task's state cannot be accessed.
        :raise: :class:`com.vmware.vapi.std.errors_provider.ServiceUnavailable`
            if the system is unable to communicate with a service to complete
            the request.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthenticated`
            if the user can not be authenticated.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unauthorized`
            if the user doesn't have the required privileges.
        :raise: :class:`com.vmware.vapi.std.errors_provider.Unsupported`
            if the task is not cancelable.
        """
        task_manager = get_task_manager()

        try:
            info_value = task_manager.get_info(task)
            info = TypeConverter.convert_to_python(info_value,
                                                   Info.get_binding_type())

            if info.status is None:    # pylint: disable=no-else-raise
                msg = message_factory.get_message(
                    'task.resource_inaccessible', task)
                logger.error(msg)
                raise ErrorFactory.new_resource_inaccessible(messages=[msg])
            elif info.status == 'SUCCEEDED' or info.status == 'FAILED':
                msg = message_factory.get_message(
                    'com.vmware.vapi.task.not_allowed_in_current_state', task)
                logger.error(msg)
                raise ErrorFactory.new_not_allowed_in_current_state(
                                    messages=[msg])
            elif not info.cancelable:
                msg = message_factory.get_message(
                    'com.vmware.vapi.task.unsupported', task)
                logger.error(msg)
                raise ErrorFactory.new_unsupported(messages=[msg])
            else:
                task_manager.mark_for_cancellation(task)

        except KeyError:
            msg = message_factory.get_message(
                'com.vmware.vapi.task.not_found', task)
            logger.error(msg)
            raise ErrorFactory.new_not_found(messages=[msg])


def register_instance():
    """
    Specify the instances that should be
    registered with the api provider
    """
    return [
        TasksImpl(),
    ]
