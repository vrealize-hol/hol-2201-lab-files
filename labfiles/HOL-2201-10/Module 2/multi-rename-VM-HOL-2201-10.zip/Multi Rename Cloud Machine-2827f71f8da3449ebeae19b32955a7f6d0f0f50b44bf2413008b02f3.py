def handler(context, inputs):
    """Set a name for a machine - accomodates multi-count machines

    :param inputs
    :param inputs.resourceNames: Contains the original name of the machine.
           It is supplied from the event data during actual provisioning
           or from user input for testing purposes.
    :param inputs.newName: The new machine name to be set.
    :return The desired machine name.
    """
    old_names = inputs["resourceNames"]
    new_name_base = inputs["customProperties"]["newName"]
    
    try:
        machineCount = int((inputs["customProperties"]["count"])) # integer value of machine count parameter
    except: # no 'count' parameter in the custom properties
        machineCount = 1    
    
    print("machine count:", machineCount)

    outputs = {}
    newNameList = []
    
    if (machineCount > 1):  # append a suffix to the new name for each machine
        name_suffix = 1
        for oldName in old_names:
            theName = new_name_base + "-" + str(name_suffix)
            print("VM name was {0}, is {1}".format(oldName, theName))
            newNameList.append(theName)
            name_suffix += 1
    else:   # just change the name - no suffix
        newNameList.append(new_name_base)
        
    outputs["resourceNames"] = newNameList
    print("Outputs: {0}".format(outputs))
    
    return outputs
